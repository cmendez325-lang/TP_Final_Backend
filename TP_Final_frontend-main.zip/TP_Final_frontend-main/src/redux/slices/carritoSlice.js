import { createSlice } from '@reduxjs/toolkit';

// Recuperamos el carrito guardado (si existe) al cargar la app
const carritoGuardado = localStorage.getItem('carrito');

const initialState = {
    items: carritoGuardado ? JSON.parse(carritoGuardado) : [], // { id, nombre, precio, imagen, cantidad }
};

// Guarda el estado actual del carrito en localStorage
const guardarEnLocalStorage = (items) => {
    localStorage.setItem('carrito', JSON.stringify(items));
};

export const carritoSlice = createSlice({
    name: 'carrito',
    initialState,
    reducers: {
        agregarAlCarrito: (state, action) => {
            const producto = action.payload;
            const idProducto = producto._id || producto.id;
            const existe = state.items.find(item => (item._id || item.id) === idProducto);

            if (existe) {
                existe.cantidad += 1;
            } else {
                state.items.push({ ...producto, cantidad: 1 });
            }
            guardarEnLocalStorage(state.items);
        },
        eliminarDelCarrito: (state, action) => {
            const idProducto = action.payload;
            state.items = state.items.filter(item => (item._id || item.id) !== idProducto);
            guardarEnLocalStorage(state.items);
        },
        vaciarCarrito: (state) => {
            state.items = [];
            guardarEnLocalStorage(state.items);
        }
    }
});

export const { agregarAlCarrito, eliminarDelCarrito, vaciarCarrito } = carritoSlice.actions;
export default carritoSlice.reducer;