// src/redux/slices/authSlice.js
import { createSlice } from '@reduxjs/toolkit';

const usuarioGuardado = localStorage.getItem('usuario');

const initialState = {
  token: localStorage.getItem('token') || null,
  isAuthenticated: !!localStorage.getItem('token'),
  user: usuarioGuardado ? JSON.parse(usuarioGuardado) : null,
};

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setCredentials: (state, action) => {
      state.token = action.payload.token;
      state.isAuthenticated = true;
      state.user = action.payload.user || null;
      localStorage.setItem('token', action.payload.token);
      if (action.payload.user) {
        localStorage.setItem('usuario', JSON.stringify(action.payload.user));
      }
    },
    logout: (state) => {
      state.token = null;
      state.isAuthenticated = false;
      state.user = null;
      localStorage.removeItem('token');
      localStorage.removeItem('usuario');
    },
  },
});

export const { setCredentials, logout } = authSlice.actions;
export default authSlice.reducer;
