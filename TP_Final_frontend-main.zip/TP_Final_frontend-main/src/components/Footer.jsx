import React from 'react';
import './Footer.css';

export default function Footer() {
    return (
        <footer className="footer">
            <p>&copy; 2026 - Trabajo Práctico Final | Desarrollado con React, Redux y Express.</p>
            <ul className="footer-links">
                <li><a href="/terminos">Términos y condiciones</a></li>
                <li><a href="/contacto">Contacto</a></li>
            </ul>
        </footer>
    );
}