import React from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

export default function HomeGrid() {
    
    // Función de Axios para agregar al carrito directamente desde el Home
    const agregarAlCarrito = async (productoId) => {
        try {
            const token = localStorage.getItem('token');
            
            await axios.post(
                'http://localhost:4000/api/carrito', 
                { productoId, cantidad: 1 }, 
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            alert('¡Producto agregado al carrito exitosamente!');
        } catch (error) {
            const mensajeError = error.response?.data?.mensaje || error.response?.data?.error || 'Ocurrió un problema';
            console.error('Detalle del error:', error.response?.data);
            alert(`Error: ${mensajeError}`);
        }
    };

    const styles = {
        gridContainer: {
            maxWidth: '1200px',
            margin: '-40px auto 30px auto',
            position: 'relative',
            zIndex: 10,
            padding: '0 20px',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '15px'
        },
        card: {
            background: '#fff',
            borderRadius: '8px',
            padding: '20px',
            boxShadow: '0 4px 10px rgba(0,0,0,0.1)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between'
        },
        title: {
            fontSize: '15px',
            color: '#666',
            margin: '0 0 5px 0'
        },
        productName: {
            fontSize: '16px',
            fontWeight: '600',
            color: '#333',
            margin: '0 0 10px 0'
        },
        price: {
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#333',
            margin: '10px 0'
        },
        imageContainer: {
            width: '100%',
            height: '110px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '10px 0'
        },
        image: {
            maxHeight: '100%',
            maxWidth: '100%',
            objectFit: 'contain'
        },
        button: {
            backgroundColor: '#3483fa',
            color: '#fff',
            border: 'none',
            borderRadius: '6px',
            padding: '10px',
            fontWeight: '600',
            cursor: 'pointer',
            width: '100%',
            marginTop: '10px',
            transition: 'background 0.2s'
        }
    };

    return (
        <div style={styles.gridContainer}>
            {/* Tarjeta 1 */}
            <div style={styles.card}>
                <div>
                    <h3 style={styles.title}>Porque te interesa</h3>
                    <p style={styles.productName}>Teclado Mecánico RGB</p>
                    <p style={styles.price}>$ 45.000</p>
                </div>
                <div style={styles.imageContainer}>
                    <img src="/cajas/placeholder.jpg" alt="Teclado" style={styles.image} />
                </div>
                <button 
                    style={styles.button} 
                    onClick={() => agregarAlCarrito('650c1234567890abcdef1234')} // Reemplazá con el ID real de tu BD si querés
                >
                    Agregar al carrito
                </button>
            </div>

            {/* Tarjeta 2 */}
            <div style={styles.card}>
                <div>
                    <h3 style={styles.title}>Lo querés</h3>
                    <p style={styles.productName}>Mouse Gamer 7200DPI</p>
                    <p style={styles.price}>$ 17.990</p>
                </div>
                <div style={styles.imageContainer}>
                    <img src="/cajas/mouse.jpg" alt="Mouse" style={styles.image} />
                </div>
                <button 
                    style={styles.button} 
                    onClick={() => agregarAlCarrito('650c1234567890abcdef1235')}
                >
                    Agregar al carrito
                </button>
            </div>

            {/* Tarjeta 3 */}
            <div style={styles.card}>
                <div>
                    <h3 style={styles.title}>Visto recientemente</h3>
                    <p style={styles.productName}>Placa de Video RTX</p>
                    <p style={styles.price}>$ 2.558.174</p>
                </div>
                <div style={styles.imageContainer}>
                    <img src="/cajas/placa.jpg" alt="Placa" style={styles.image} />
                </div>
                <button 
                    style={styles.button} 
                    onClick={() => agregarAlCarrito('650c1234567890abcdef1236')}
                >
                    Agregar al carrito
                </button>
            </div>

            {/* Tarjeta 4: Enlace directo al carrito */}
            <div style={styles.card}>
                <div>
                    <h3 style={styles.title}>Comprá tu carrito</h3>
                    <p style={styles.productName}>Ver productos cargados</p>
                </div>
                <div style={styles.imageContainer}>
                    <img src="/cajas/placeholder.jpg" alt="Carrito" style={styles.image} />
                </div>
                <Link to="/carrito" style={{ ...styles.button, display: 'block', textAlign: 'center', textDecoration: 'none', boxSizing: 'border-box' }}>
                    Ir al carrito →
                </Link>
            </div>
        </div>
    );
}