import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setCredentials } from '../redux/slices/authSlice';
import "./Login.css";

export default function Login() {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [esRegistro, setEsRegistro] = useState(false);
    const [mostrarPassword, setMostrarPassword] = useState(false);
    const [cargando, setCargando] = useState(false);
    const [erroresForm, setErroresForm] = useState({});

    const [formData, setFormData] = useState({
        nombre: '',
        email: '',
        password: '',
        ciudad: '',
        pais: '',
        edad: '',
        direccion: '',
    });

    // Reglas de validación por campo. Solo exigimos ciudad/país/dirección/edad en modo registro.
    const validarCampo = (nombreCampo, valor) => {
        switch (nombreCampo) {
            case 'nombre': {
                if (!esRegistro) return null;
                if (!valor.trim()) return 'El nombre es obligatorio.';
                if (/^\d+$/.test(valor.trim())) return 'El nombre no puede ser solo números.';
                if (valor.trim().length < 3) return 'El nombre debe tener al menos 3 caracteres.';
                if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(valor.trim())) return 'El nombre solo puede contener letras y espacios.';
                return null;
            }
            case 'email': {
                if (!valor.trim()) return 'El email es obligatorio.';
                const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!regexEmail.test(valor.trim())) return 'Ingresá un email válido.';
                return null;
            }
            case 'password': {
                if (!valor) return 'La contraseña es obligatoria.';
                if (valor.length < 6) return 'La contraseña debe tener al menos 6 caracteres.';
                if (esRegistro && !/\d/.test(valor)) return 'La contraseña debe incluir al menos un número.';
                return null;
            }
            case 'edad': {
                if (!esRegistro) return null;
                if (valor === '') return null; // opcional
                const edadNum = Number(valor);
                if (!Number.isInteger(edadNum)) return 'La edad debe ser un número entero.';
                if (edadNum < 13) return 'Debés tener al menos 13 años para registrarte.';
                if (edadNum > 120) return 'Ingresá una edad válida.';
                return null;
            }
            default:
                return null;
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;
        const mensaje = validarCampo(name, value);
        setErroresForm((prev) => ({ ...prev, [name]: mensaje }));
    };

    const formEsValido = () => {
        const camposARevisar = esRegistro
            ? ['nombre', 'email', 'password', 'edad']
            : ['email', 'password'];

        const nuevosErrores = {};
        camposARevisar.forEach((campo) => {
            const mensaje = validarCampo(campo, formData[campo]);
            if (mensaje) nuevosErrores[campo] = mensaje;
        });
        setErroresForm(nuevosErrores);
        return Object.keys(nuevosErrores).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formEsValido()) {
            return;
        }

        setCargando(true);

        try {
            if (esRegistro) {
                const datosRegistro = {
                    ...formData,
                    edad: formData.edad ? Number(formData.edad) : undefined,
                };
                await axios.post('http://localhost:4000/api/auth/register', datosRegistro);

                const respuestaLogin = await axios.post('http://localhost:4000/api/auth/login', {
                    email: formData.email,
                    password: formData.password,
                });

                dispatch(setCredentials({
                    token: respuestaLogin.data.token,
                    user: respuestaLogin.data.usuario,
                }));

                alert('¡Cuenta creada e iniciada sesión exitosamente!');
            } else {
                const respuesta = await axios.post('http://localhost:4000/api/auth/login', {
                    email: formData.email,
                    password: formData.password,
                });

                dispatch(setCredentials({
                    token: respuesta.data.token,
                    user: respuesta.data.usuario,
                }));

                alert('¡Bienvenido/a de nuevo!');
            }

            navigate('/');
        } catch (error) {
            const mensajeError = error.response?.data?.mensaje || error.response?.data?.error || 'Ocurrió un problema';
            console.error('Detalle del error:', error.response?.data);
            alert(`Error: ${mensajeError}`);
        } finally {
            setCargando(false);
        }
    };

    const cambiarModo = () => {
        setEsRegistro((prev) => !prev);
        setErroresForm({});
    };

    return (
        <div className="login-container">
            <div className="login-card">
                <h2>{esRegistro ? 'Crear cuenta' : 'Iniciar sesión'}</h2>

                <form onSubmit={handleSubmit} noValidate>
                    {esRegistro && (
                        <>
                            <div className="form-group">
                                <label htmlFor="nombre">Nombre</label>
                                <input
                                    id="nombre"
                                    name="nombre"
                                    type="text"
                                    placeholder="Tu nombre y apellido"
                                    value={formData.nombre}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                    className={erroresForm.nombre ? 'campo-error' : ''}
                                />
                                {erroresForm.nombre && <span className="texto-error">{erroresForm.nombre}</span>}
                            </div>

                            <div className="form-group">
                                <label htmlFor="edad">Edad</label>
                                <input
                                    id="edad"
                                    name="edad"
                                    type="number"
                                    min="13"
                                    max="120"
                                    placeholder="Tu edad"
                                    value={formData.edad}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                    className={erroresForm.edad ? 'campo-error' : ''}
                                />
                                {erroresForm.edad && <span className="texto-error">{erroresForm.edad}</span>}
                            </div>

                            <div className="form-group">
                                <label htmlFor="ciudad">Ciudad</label>
                                <input
                                    id="ciudad"
                                    name="ciudad"
                                    type="text"
                                    placeholder="Tu ciudad"
                                    value={formData.ciudad}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="pais">País</label>
                                <input
                                    id="pais"
                                    name="pais"
                                    type="text"
                                    placeholder="Tu país"
                                    value={formData.pais}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="direccion">Dirección</label>
                                <input
                                    id="direccion"
                                    name="direccion"
                                    type="text"
                                    placeholder="Tu dirección"
                                    value={formData.direccion}
                                    onChange={handleChange}
                                />
                            </div>
                        </>
                    )}

                    <div className="form-group">
                        <label htmlFor="email">Email</label>
                        <input
                            id="email"
                            name="email"
                            type="email"
                            placeholder="Tu email"
                            value={formData.email}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            className={erroresForm.email ? 'campo-error' : ''}
                        />
                        {erroresForm.email && <span className="texto-error">{erroresForm.email}</span>}
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">Contraseña</label>
                        <div className="password-wrapper">
                            <input
                                id="password"
                                name="password"
                                type={mostrarPassword ? 'text' : 'password'}
                                placeholder="Mínimo 6 caracteres y un número"
                                value={formData.password}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={erroresForm.password ? 'campo-error' : ''}
                            />
                            <button
                                type="button"
                                onClick={() => setMostrarPassword((prev) => !prev)}
                            >
                                {mostrarPassword ? '🙈' : '👁️'}
                            </button>
                        </div>
                        {erroresForm.password && <span className="texto-error">{erroresForm.password}</span>}
                        {esRegistro && !erroresForm.password && (
                            <span className="texto-ayuda">Mínimo 6 caracteres, incluyendo al menos un número.</span>
                        )}
                    </div>

                    <button type="submit" className="btn-submit" disabled={cargando}>
                        {cargando ? 'Cargando...' : (esRegistro ? 'Registrarme' : 'Ingresar')}
                    </button>
                </form>

                <p className="toggle-auth" onClick={cambiarModo}>
                    {esRegistro
                        ? '¿Ya tenés cuenta? Iniciá sesión'
                        : '¿No tenés cuenta? Registrate'}
                </p>
            </div>
        </div>
    );
}
