import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import axios from 'axios';
import { agregarAlCarrito as agregarAlCarritoRedux } from '../redux/slices/carritoSlice';
import Spinner from './Spinner';
import './CarruselHome.css';

import fondo1 from '../assets/img/fondoteclado.jpg';
import fondo2 from '../assets/img/banner2.jpg';
import fondo3 from '../assets/img/banner3.jpg';

const imgTeclado = '/cajas/Teclado.jpg';
const imgMouse = '/cajas/mouse.jpg';
const imgPlaca = '/cajas/placa.jpg';

// Palabras clave para matchear cada tarjeta con un producto real de la BD
const CARDS_INFO = [
    {
        key: 'teclado',
        palabras: ['teclado'],
        categoria: 'Porque te interesa',
        imagen: imgTeclado,
        alt: 'Teclado Mecánico',
        nombreFallback: 'Teclado Mecánico RGB',
        precioFallback: '45.000',
        detalle: 'Envío gratis',
    },
    {
        key: 'mouse',
        palabras: ['mouse', 'raton'],
        categoria: 'Lo querés',
        imagen: imgMouse,
        alt: 'Mouse Gamer',
        nombreFallback: 'Mouse Gamer 7200DPI',
        precioFallback: '17.990',
        detalle: 'Envío gratis',
    },
    {
        key: 'placa',
        palabras: ['placa', 'video', 'rtx', 'gpu'],
        categoria: 'Visto recientemente',
        imagen: imgPlaca,
        alt: 'Placa de Video',
        nombreFallback: 'Placa de Video RTX',
        precioFallback: '2.558.174',
        detalle: '18% OFF',
    },
];

export default function CarruselHome() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [productos, setProductos] = useState([]);
    const [cargandoProductos, setCargandoProductos] = useState(true);

    // Traemos los productos reales para poder mostrar nombre/precio reales y agregar al carrito con su _id verdadero
    useEffect(() => {
        const obtenerProductos = async () => {
            try {
                const respuesta = await axios.get('http://localhost:4000/api/productos');
                setProductos(respuesta.data);
            } catch (error) {
                console.error('Error al cargar productos para el carrusel:', error);
            } finally {
                setCargandoProductos(false);
            }
        };
        obtenerProductos();
    }, []);

    const agregarAlCarrito = (productoReal, imagen, e) => {
        e.stopPropagation();
        e.preventDefault();

        if (!productoReal) {
            alert('Este producto todavía no está cargado en la base de datos.');
            return;
        }

        dispatch(agregarAlCarritoRedux({
            _id: productoReal._id,
            nombre: productoReal.nombre,
            precio: productoReal.precio,
            imagen: productoReal.imagen || imagen,
        }));
        alert('¡Producto agregado al carrito exitosamente!');
    };

    // Busca el producto real en la BD que matchea con las palabras clave de la tarjeta
    const buscarProductoReal = (palabras) => {
        return productos.find((producto) => {
            const nombre = (producto.nombre || '').toLowerCase();
            return palabras.some((palabra) => nombre.includes(palabra));
        });
    };

    const slides = [
        { imagen: fondo1, link: "/catalogo?q=teclado" },
        { imagen: fondo2, link: "/catalogo?q=mouse" },
        { imagen: fondo3, link: "/catalogo?q=placa" }
    ];

    const [currentIndex, setCurrentIndex] = useState(0);
    const [isHovered, setIsHovered] = useState(false);

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
        }, 4000);
        return () => clearInterval(timer);
    }, [slides.length]);

    const prevSlide = (e) => {
        e.stopPropagation();
        setCurrentIndex((prevIndex) => (prevIndex === 0 ? slides.length - 1 : prevIndex - 1));
    };

    const nextSlide = (e) => {
        e.stopPropagation();
        setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
    };

    const slideActual = slides[currentIndex];

    return (
        <div className="carrusel-container">
            {/* Carrusel superior con imágenes de fondo fijas */}
            <div
                onClick={() => navigate(slideActual.link)}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                className="carrusel-banner-fondo"
                style={{ backgroundImage: `url(${slideActual.imagen})` }}
            >
                <button
                    onClick={prevSlide}
                    className="carrusel-btn-flecha"
                    style={{ opacity: isHovered ? 1 : 0 }}
                >
                    ‹
                </button>

                <button
                    onClick={nextSlide}
                    className="carrusel-btn-flecha"
                    style={{ opacity: isHovered ? 1 : 0 }}
                >
                    ›
                </button>
            </div>

            {/* Cajas de accesos directos */}
            {cargandoProductos ? (
                <Spinner texto="Cargando productos destacados..." />
            ) : (
                <div className="carrusel-grid">
                    {CARDS_INFO.map((card) => {
                        const productoReal = buscarProductoReal(card.palabras);
                        const nombre = productoReal?.nombre || card.nombreFallback;
                        const precio = productoReal?.precio
                            ? productoReal.precio.toLocaleString('es-AR')
                            : card.precioFallback;
                        const imagenMostrada = productoReal?.imagen || card.imagen;

                        return (
                            <Link
                                key={card.key}
                                to={`/catalogo?q=${card.key}`}
                                className="carrusel-card"
                            >
                                <span className="card-categoria">{card.categoria}</span>
                                <img
                                    src={imagenMostrada}
                                    alt={card.alt}
                                    onError={(e) => { e.target.onerror = null; e.target.src = '/cajas/placeholder.jpg'; }}
                                />
                                <div className="card-info">
                                    <h3>{nombre}</h3>
                                    <span className="card-precio">$ {precio}</span>
                                    <span className="card-detalle">{card.detalle}</span>
                                    <button
                                        className="card-agregar-btn"
                                        onClick={(e) => agregarAlCarrito(productoReal, card.imagen, e)}
                                    >
                                        Agregar al carrito
                                    </button>
                                </div>
                            </Link>
                        );
                    })}

                    {/* Caja extra: Carrito / Finalizar */}
                    <Link to="/carrito" className="carrusel-card">
                        <span className="card-categoria">Comprá tu carrito</span>
                        <img src={imgTeclado} alt="Tu Carrito" />
                        <div className="card-info">
                            <h3>Ver productos cargados</h3>
                            <span className="card-detalle link-carrito">Ir al carrito →</span>
                        </div>
                    </Link>
                </div>
            )}
        </div>
    );
}
