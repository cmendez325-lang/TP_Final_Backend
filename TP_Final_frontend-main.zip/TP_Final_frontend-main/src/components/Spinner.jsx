import React from 'react';
import './Spinner.css';

export default function Spinner({ texto = 'Cargando...' }) {
    return (
        <div className="spinner-container">
            <div className="spinner"></div>
            <p className="spinner-texto">{texto}</p>
        </div>
    );
}
