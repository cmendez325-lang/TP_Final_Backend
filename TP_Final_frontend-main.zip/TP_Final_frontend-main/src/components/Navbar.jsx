import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../redux/slices/authSlice';
import './Navbar.css';

export default function Navbar() {
    const [busqueda, setBusqueda] = useState('');
    const [mostrarPerfil, setMostrarPerfil] = useState(false);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const items = useSelector((state) => state.carrito?.items || []);
    const cantidadTotal = items.reduce((acc, item) => acc + item.cantidad, 0);

    const { isAuthenticated, user } = useSelector((state) => state.auth);
    const puedeVerAdmin = user?.rol === 'admin' || user?.rol === 'vendedor';

    const handleSearch = (e) => {
        e.preventDefault();
        if (busqueda.trim() !== '') {
            navigate(`/catalogo?q=${encodeURIComponent(busqueda)}`);
        }
    };

    const handleLogout = () => {
        dispatch(logout());
        setMostrarPerfil(false);
        navigate('/');
    };

    return (
        <header className="navbar">
            <div className="navbar-brand">
                <Link to="/">TP Final</Link>
            </div>

            {/* Buscador */}
            <form onSubmit={handleSearch} className="navbar-form">
                <input
                    type="text"
                    placeholder="Buscar productos, marcas y más..."
                    value={busqueda}
                    onChange={(e) => setBusqueda(e.target.value)}
                    className="navbar-search-input"
                />
                <button type="submit" className="navbar-search-btn">
                    🔍
                </button>
            </form>

            <nav className="navbar-links">
                <Link to="/">Inicio</Link>
                <Link to="/catalogo">Catálogo</Link>

                {puedeVerAdmin && (
                    <Link to="/admin">Admin</Link>
                )}

                <Link to="/carrito" className="navbar-cart-link" title="Ver Carrito">
                    🛒
                    {cantidadTotal > 0 && (
                        <span className="navbar-cart-badge">
                            {cantidadTotal}
                        </span>
                    )}
                </Link>

                {isAuthenticated ? (
                    <div className="navbar-profile-wrapper">
                        <button
                            onClick={() => setMostrarPerfil((prev) => !prev)}
                            className="navbar-profile-btn"
                        >
                            Hola, <strong>{user?.nombre}</strong>
                            {user?.rol && user.rol !== 'user' && (
                                <span className="navbar-profile-role">
                                    {user.rol}
                                </span>
                            )}
                            <span style={{ fontSize: '10px' }}>▾</span>
                        </button>

                        {mostrarPerfil && (
                            <div className="navbar-profile-dropdown">
                                <h4>{user?.nombre}</h4>
                                <div className="navbar-profile-info">
                                    <span>📧 {user?.email}</span>
                                    {user?.ciudad && <span>🏙️ {user.ciudad}</span>}
                                    {user?.pais && <span>🌎 {user.pais}</span>}
                                    {user?.direccion && <span>📍 {user.direccion}</span>}
                                    {user?.edad && <span>🎂 {user.edad} años</span>}
                                    <span>🔖 Rol: {user?.rol}</span>
                                </div>
                                <Link
                                    to="/perfil"
                                    onClick={() => setMostrarPerfil(false)}
                                    className="navbar-btn-edit"
                                >
                                    Editar perfil
                                </Link>
                                <button
                                    onClick={handleLogout}
                                    className="navbar-btn-logout"
                                >
                                    Cerrar sesión
                                </button>
                            </div>
                        )}
                    </div>
                ) : (
                    <Link to="/login" className="navbar-login-link">Login / Register</Link>
                )}
            </nav>
        </header>
    );
}