import React from 'react';
import { useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';

/**
 * Protege una ruta según autenticación y, opcionalmente, rol.
 *
 * Uso:
 *   <RutaProtegida rolesPermitidos={['admin', 'vendedor']}>
 *     <AdminPanel />
 *   </RutaProtegida>
 */
export default function RutaProtegida({ children, rolesPermitidos }) {
    const { isAuthenticated, user } = useSelector((state) => state.auth);

    if (!isAuthenticated) {
        return <Navigate to="/login" replace />;
    }

    if (rolesPermitidos && !rolesPermitidos.includes(user?.rol)) {
        return (
            <div style={{ padding: '40px', textAlign: 'center' }}>
                <h2>Acceso denegado</h2>
                <p style={{ color: '#666' }}>No tenés permisos para ver esta sección.</p>
            </div>
        );
    }

    return children;
}
