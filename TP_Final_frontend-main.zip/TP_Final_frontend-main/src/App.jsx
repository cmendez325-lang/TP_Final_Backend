import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import CarruselHome from './components/CarruselHome';
import Catalogo from './pages/Catalogo';
import Carrito from './pages/Carrito';
import Login from './components/Login';
import AdminPanel from './pages/AdminPanel';
import Perfil from './pages/Perfil';
import RutaProtegida from './components/RutaProtegida';

function App() {
  return (
    <Router>
      {/* 1. Navbar global arriba */}
      <Navbar />

      {/* 2. Las rutas que cambian según la página */}
      <Routes>
        <Route path="/" element={<CarruselHome />} />
        <Route path="/catalogo" element={<Catalogo />} />
        <Route path="/carrito" element={<Carrito />} />
        <Route path="/login" element={<Login />} />
        <Route
          path="/admin"
          element={
            <RutaProtegida rolesPermitidos={['admin', 'vendedor']}>
              <AdminPanel />
            </RutaProtegida>
          }
        />
        <Route
          path="/perfil"
          element={
            <RutaProtegida>
              <Perfil />
            </RutaProtegida>
          }
        />
      </Routes>

      {/* 3. Footer global abajo */}
      <Footer />
    </Router>
  );
}

export default App;
