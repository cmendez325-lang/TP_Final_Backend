import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useSelector, useDispatch } from 'react-redux';
import { setCredentials } from '../redux/slices/authSlice';

export default function Perfil() {
    const { token, user } = useSelector((state) => state.auth);
    const dispatch = useDispatch();

    const [formData, setFormData] = useState({
        nombre: '',
        email: '',
        ciudad: '',
        pais: '',
        edad: '',
        direccion: '',
    });
    const [cargando, setCargando] = useState(false);
    const [mensaje, setMensaje] = useState(null);

    const headers = { Authorization: `Bearer ${token}` };

    // Precargamos el formulario con los datos actuales del usuario
    useEffect(() => {
        if (user) {
            setFormData({
                nombre: user.nombre || '',
                email: user.email || '',
                ciudad: user.ciudad || '',
                pais: user.pais || '',
                edad: user.edad || '',
                direccion: user.direccion || '',
            });
        }
    }, [user]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setCargando(true);
        setMensaje(null);

        try {
            const datosAEnviar = {
                ...formData,
                edad: formData.edad ? Number(formData.edad) : undefined,
            };

            const respuesta = await axios.put(
                'http://localhost:4000/api/usuarios/perfil',
                datosAEnviar,
                { headers }
            );

            // Actualizamos el usuario en Redux/localStorage con los datos nuevos,
            // manteniendo el mismo token y rol.
            dispatch(setCredentials({
                token,
                user: {
                    ...user,
                    ...respuesta.data.usuario,
                },
            }));

            setMensaje({ tipo: 'exito', texto: '¡Perfil actualizado correctamente!' });
        } catch (error) {
            const texto = error.response?.data?.mensaje || 'No se pudo actualizar el perfil.';
            setMensaje({ tipo: 'error', texto });
        } finally {
            setCargando(false);
        }
    };

    if (!user) {
        return (
            <div style={{ padding: '40px', textAlign: 'center' }}>
                <h3>Necesitás iniciar sesión para ver tu perfil.</h3>
            </div>
        );
    }

    return (
        <div style={{ maxWidth: '500px', margin: '40px auto', padding: '0 20px' }}>
            <div style={{ background: '#fff', padding: '30px', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
                <h2 style={{ marginTop: 0 }}>Mi Perfil</h2>
                <p style={{ color: '#888', fontSize: '13px', marginTop: '-10px' }}>
                    Rol: <strong>{user.rol}</strong>
                </p>

                {mensaje && (
                    <div style={{
                        padding: '10px 14px',
                        borderRadius: '4px',
                        marginBottom: '15px',
                        fontSize: '14px',
                        background: mensaje.tipo === 'exito' ? '#d4edda' : '#f8d7da',
                        color: mensaje.tipo === 'exito' ? '#155724' : '#721c24',
                    }}>
                        {mensaje.texto}
                    </div>
                )}

                <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#495057' }}>Nombre</label>
                        <input
                            name="nombre"
                            type="text"
                            value={formData.nombre}
                            onChange={handleChange}
                            style={{ padding: '10px', border: '1px solid #ced4da', borderRadius: '4px' }}
                        />
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#495057' }}>Email</label>
                        <input
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleChange}
                            style={{ padding: '10px', border: '1px solid #ced4da', borderRadius: '4px' }}
                        />
                    </div>

                    <div style={{ display: 'flex', gap: '10px' }}>
                        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#495057' }}>Edad</label>
                            <input
                                name="edad"
                                type="number"
                                min="13"
                                max="120"
                                value={formData.edad}
                                onChange={handleChange}
                                style={{ padding: '10px', border: '1px solid #ced4da', borderRadius: '4px' }}
                            />
                        </div>
                        <div style={{ flex: 2, display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#495057' }}>Ciudad</label>
                            <input
                                name="ciudad"
                                type="text"
                                value={formData.ciudad}
                                onChange={handleChange}
                                style={{ padding: '10px', border: '1px solid #ced4da', borderRadius: '4px' }}
                            />
                        </div>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#495057' }}>País</label>
                        <input
                            name="pais"
                            type="text"
                            value={formData.pais}
                            onChange={handleChange}
                            style={{ padding: '10px', border: '1px solid #ced4da', borderRadius: '4px' }}
                        />
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#495057' }}>Dirección</label>
                        <input
                            name="direccion"
                            type="text"
                            value={formData.direccion}
                            onChange={handleChange}
                            style={{ padding: '10px', border: '1px solid #ced4da', borderRadius: '4px' }}
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={cargando}
                        style={{
                            marginTop: '10px',
                            padding: '12px',
                            background: '#28a745',
                            color: '#fff',
                            border: 'none',
                            borderRadius: '4px',
                            fontWeight: 'bold',
                            cursor: 'pointer'
                        }}
                    >
                        {cargando ? 'Guardando...' : 'Guardar cambios'}
                    </button>
                </form>
            </div>
        </div>
    );
}
