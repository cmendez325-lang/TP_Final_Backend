import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Spinner from './Spinner';
import './CarruselHome.css';

export default function CarruselHome() {
    const [productos, setProductos] = useState([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        axios.get('http://localhost:4000/api/productos')
            .then((response) => {
                setProductos(response.data);
            })
            .catch((err) => {
                console.error('Error al cargar productos para el carrusel:', err);
            })
            .finally(() => {
                setLoading(false);
            });
    }, []);

    useEffect(() => {
        if (productos.length === 0) return;
        const interval = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % productos.length);
        }, 4000);
        return () => clearInterval(interval);
    }, [productos]);

    if (loading) {
        return <Spinner texto="Cargando ofertas destacadas..." />;
    }

    if (productos.length === 0) {
        return <div className="carrusel-cargando">No hay ofertas para mostrar por el momento.</div>;
    }

    const productoActual = productos[currentIndex];

    return (
        <div className="carrusel-banner">
            <div className="carrusel-contenido">
                {/* Lado Izquierdo: Textos promocionales */}
                <div className="carrusel-texto">
                    <span className="carrusel-categoria">
                        {productoActual.categoria || 'Destacado'}
                    </span>
                    <h1 className="carrusel-nombre">
                        {productoActual.nombre}
                    </h1>
                    <p className="carrusel-precio">
                        ${productoActual.precio?.toLocaleString()}
                    </p>
                    <button className="carrusel-btn-ver">
                        Ver producto
                    </button>
                </div>

                {/* Lado Derecho: Imagen del producto y controles */}
                <div className="carrusel-imagen-wrapper">
                    <img
                        src={productoActual.imagen || '/cajas/placeholder.jpg'}
                        alt={productoActual.nombre}
                        className="carrusel-imagen"
                        onError={(e) => { e.target.onerror = null; e.target.src = '/cajas/placeholder.jpg'; }}
                    />

                    {/* Botones de navegación tipo banner */}
                    <div className="carrusel-controles">
                        <button
                            className="carrusel-btn-control"
                            onClick={() => setCurrentIndex((currentIndex - 1 + productos.length) % productos.length)}
                        >
                            ❮
                        </button>
                        <button
                            className="carrusel-btn-control"
                            onClick={() => setCurrentIndex((currentIndex + 1) % productos.length)}
                        >
                            ❯
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
