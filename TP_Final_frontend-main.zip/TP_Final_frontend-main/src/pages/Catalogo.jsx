import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useSearchParams } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { agregarAlCarrito as agregarAlCarritoRedux } from '../redux/slices/carritoSlice';
import './Catalogo.css';


export default function Catalogo() {
    const [productos, setProductos] = useState([]);
    const [searchParams] = useSearchParams();
    const dispatch = useDispatch();

    const terminoBusqueda = searchParams.get('q') || '';

    // Cargar los productos de la API al montar el componente
    useEffect(() => {
        const obtenerProductos = async () => {
            try {
                const respuesta = await axios.get('http://localhost:4000/api/productos');
                setProductos(respuesta.data);
            } catch (error) {
                console.error('Error al cargar productos:', error);
            }
        };
        obtenerProductos();
    }, []);

    // Filtramos por nombre, descripción o categoría (case-insensitive)
    const productosFiltrados = terminoBusqueda
        ? productos.filter((producto) => {
            const termino = terminoBusqueda.toLowerCase();
            return (
                producto.nombre?.toLowerCase().includes(termino) ||
                producto.descripcion?.toLowerCase().includes(termino) ||
                producto.categoria?.toLowerCase().includes(termino)
            );
        })
        : productos;

    // Mapeo temporal: como la BD todavía no tiene campo "imagen",
    // asignamos una imagen según palabras clave en el nombre del producto.
    const mapaImagenesPorNombre = [
        { palabras: ['placa', 'video', 'rtx', 'gpu'], archivo: 'placa.jpg' },
        { palabras: ['mouse', 'raton'], archivo: 'mouse.jpg' },
        { palabras: ['teclado'], archivo: 'Teclado.jpg' },
    ];

    // Función auxiliar para resolver la ruta de la imagen de forma segura
    const obtenerImagenUrl = (producto) => {
        const imagen = producto?.imagen;

        if (imagen) {
            if (imagen.startsWith('http')) return imagen; // URL externa
            if (imagen.startsWith('/')) return imagen; // Ya tiene barra
            return `/cajas/${imagen}`; // Solo el nombre del archivo
        }

        // Sin campo "imagen": buscamos coincidencia por nombre del producto
        const nombre = (producto?.nombre || '').toLowerCase();
        const coincidencia = mapaImagenesPorNombre.find(({ palabras }) =>
            palabras.some((palabra) => nombre.includes(palabra))
        );

        return coincidencia
            ? `/cajas/${coincidencia.archivo}`
            : '/cajas/placeholder.jpg';
    };

    // Agrega el producto al carrito de Redux (lo que realmente lee la pantalla Carrito.jsx)
    const agregarAlCarrito = (producto) => {
        dispatch(agregarAlCarritoRedux({
            _id: producto._id,
            nombre: producto.nombre,
            precio: producto.precio,
            imagen: obtenerImagenUrl(producto),
        }));
        alert('¡Producto agregado al carrito exitosamente!');
    };

    return (
        <div className="catalogo-container">
            <h2>
                {terminoBusqueda
                    ? `Resultados para: "${terminoBusqueda}"`
                    : 'Resultados para: "Todos los productos"'}
            </h2>

            {productosFiltrados.length === 0 ? (
                <p style={{ textAlign: 'center', color: '#666', marginTop: '30px' }}>
                    No encontramos productos que coincidan con "{terminoBusqueda}".
                </p>
            ) : (
                <div className="catalogo-grid">
                    {productosFiltrados.map((producto) => (
                        <div className="producto-card" key={producto._id}>
                            <img
                                src={obtenerImagenUrl(producto)}
                                alt={producto.nombre}
                                onError={(e) => {
                                    e.target.onerror = null;
                                    e.target.src = '/cajas/placeholder.jpg';
                                }}
                            />
                            <h3>{producto.nombre}</h3>
                            <p>$ {producto.precio}</p>

                            <button onClick={() => agregarAlCarrito(producto)}>
                                Agregar al carrito
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
