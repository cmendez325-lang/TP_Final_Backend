import { useState, useEffect } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';
import Spinner from '../components/Spinner';
import './AdminPanel.css';

const PRODUCTO_VACIO = {
    nombre: '',
    precio: '',
    descripcion: '',
    stock: '',
    categoria: ''
};

const CATEGORIAS = [
    'Periféricos',
    'Componentes',
    'Almacenamiento',
    'Monitores',
    'Audio',
    'Sillas y Escritorios',
    'Redes',
    'Otros'
];

export default function AdminPanel() {
    const { token, user } = useSelector((state) => state.auth);
    const esAdmin = user?.rol === 'admin';

    const headers = { Authorization: `Bearer ${token}` };

    // ------- PRODUCTOS -------
    const [productos, setProductos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [nuevoProducto, setNuevoProducto] = useState(PRODUCTO_VACIO);
    const [erroresForm, setErroresForm] = useState({});
    const [editandoId, setEditandoId] = useState(null);
    const [archivoImagen, setArchivoImagen] = useState(null);
    const [previewImagen, setPreviewImagen] = useState(null);
    const [guardando, setGuardando] = useState(false);

    useEffect(() => {
        obtenerProductos();
    }, []);

    const obtenerProductos = async () => {
        try {
            const respuesta = await axios.get('http://localhost:4000/api/productos');
            setProductos(respuesta.data);
            setError(null);
        } catch (err) {
            console.error(err);
            setError('No pudimos conectar con el servidor. Fijate que el backend esté corriendo e intentá de nuevo.');
        } finally {
            setLoading(false);
        }
    };

    // Vendedor ve solo lo suyo, admin ve todo
    const productosVisibles = esAdmin
        ? productos
        : productos.filter((p) => p.vendedorId === user?.id);

    const handleChange = (e) => {
        setNuevoProducto({
            ...nuevoProducto,
            [e.target.name]: e.target.value
        });
    };

    const handleImagenChange = (e) => {
        const archivo = e.target.files[0];
        if (!archivo) return;

        setArchivoImagen(archivo);
        setPreviewImagen(URL.createObjectURL(archivo));
    };

    // Validación en tiempo real: revisa un campo y devuelve el mensaje de error, o null si está bien
    const validarCampo = (nombreCampo, valor) => {
        switch (nombreCampo) {
            case 'nombre': {
                if (!valor.trim()) return 'El nombre es obligatorio.';
                if (/^\d+$/.test(valor.trim())) return 'El nombre no puede ser solo números.';
                if (valor.trim().length < 3) return 'El nombre debe tener al menos 3 caracteres.';
                return null;
            }
            case 'precio': {
                if (valor === '') return 'El precio es obligatorio.';
                if (Number(valor) <= 0) return 'El precio debe ser mayor a 0.';
                return null;
            }
            case 'stock': {
                if (valor === '') return 'El stock es obligatorio.';
                if (Number(valor) < 0 || !Number.isInteger(Number(valor))) return 'El stock debe ser un número entero, 0 o mayor.';
                return null;
            }
            case 'descripcion': {
                if (!valor.trim()) return 'La descripción es obligatoria.';
                if (valor.trim().length < 10) return 'Agregá una descripción un poco más detallada (mínimo 10 caracteres).';
                return null;
            }
            case 'categoria': {
                if (!valor) return 'Elegí una categoría.';
                return null;
            }
            default:
                return null;
        }
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;
        const mensaje = validarCampo(name, value);
        setErroresForm((prev) => ({ ...prev, [name]: mensaje }));
    };

    const formEsValido = () => {
        const nuevosErrores = {};
        Object.keys(nuevoProducto).forEach((campo) => {
            const mensaje = validarCampo(campo, nuevoProducto[campo]);
            if (mensaje) nuevosErrores[campo] = mensaje;
        });
        setErroresForm(nuevosErrores);
        return Object.keys(nuevosErrores).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formEsValido()) {
            return;
        }

        // Usamos FormData para poder mandar el archivo de imagen junto con el resto de los datos
        const formDataAEnviar = new FormData();
        Object.entries(nuevoProducto).forEach(([clave, valor]) => {
            formDataAEnviar.append(clave, valor);
        });
        if (archivoImagen) {
            formDataAEnviar.append('imagen', archivoImagen);
        }

        setGuardando(true);
        try {
            if (editandoId) {
                await axios.put(
                    `http://localhost:4000/api/productos/${editandoId}`,
                    formDataAEnviar,
                    { headers }
                );
            } else {
                await axios.post('http://localhost:4000/api/productos', formDataAEnviar, { headers });
            }
            cancelarEdicion();
            await obtenerProductos();
        } catch (err) {
            console.error(err);
            const mensaje = err.response?.data?.mensaje || 'No pudimos guardar el producto. Revisá los datos e intentá de nuevo.';
            alert(mensaje);
        } finally {
            setGuardando(false);
        }
    };

    const empezarEdicion = (producto) => {
        setEditandoId(producto._id);
        setErroresForm({});
        setArchivoImagen(null);
        setPreviewImagen(producto.imagen || null);
        setNuevoProducto({
            nombre: producto.nombre,
            precio: producto.precio,
            descripcion: producto.descripcion,
            stock: producto.stock,
            categoria: producto.categoria
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const cancelarEdicion = () => {
        setEditandoId(null);
        setErroresForm({});
        setArchivoImagen(null);
        setPreviewImagen(null);
        setNuevoProducto(PRODUCTO_VACIO);
    };

    const eliminarProducto = async (id) => {
        if (!window.confirm('¿Estás seguro de eliminar este producto? Esta acción no se puede deshacer.')) return;
        try {
            await axios.delete(`http://localhost:4000/api/productos/${id}`, { headers });
            obtenerProductos();
        } catch (err) {
            console.error(err);
            const mensaje = err.response?.data?.mensaje || 'No pudimos eliminar el producto. Intentá de nuevo en unos segundos.';
            alert(mensaje);
        }
    };

    // ------- USUARIOS (solo admin) -------
    const [usuarios, setUsuarios] = useState([]);
    const [cargandoUsuarios, setCargandoUsuarios] = useState(false);

    useEffect(() => {
        if (esAdmin) obtenerUsuarios();
    }, [esAdmin]);

    const obtenerUsuarios = async () => {
        setCargandoUsuarios(true);
        try {
            const respuesta = await axios.get('http://localhost:4000/api/usuarios', { headers });
            setUsuarios(respuesta.data);
        } catch (err) {
            console.error(err);
            alert('No pudimos cargar la lista de usuarios. Revisá tu conexión e intentá de nuevo.');
        } finally {
            setCargandoUsuarios(false);
        }
    };

    const cambiarRol = async (id, nuevoRol) => {
        try {
            await axios.put(
                `http://localhost:4000/api/usuarios/${id}/rol`,
                { rol: nuevoRol },
                { headers }
            );
            obtenerUsuarios();
        } catch (err) {
            console.error(err);
            const mensaje = err.response?.data?.mensaje || 'No pudimos cambiar el rol de este usuario.';
            alert(mensaje);
        }
    };

    const eliminarUsuario = async (id) => {
        if (!window.confirm('¿Estás seguro de eliminar este usuario? Esta acción no se puede deshacer.')) return;
        try {
            await axios.delete(`http://localhost:4000/api/usuarios/${id}`, { headers });
            obtenerUsuarios();
        } catch (err) {
            console.error(err);
            const mensaje = err.response?.data?.mensaje || 'No pudimos eliminar este usuario.';
            alert(mensaje);
        }
    };

    if (loading) {
        return <Spinner texto="Cargando panel administrativo..." />;
    }

    if (error) {
        return (
            <div className="admin-error">
                <h3>{error}</h3>
            </div>
        );
    }

    return (
        <div className="admin-container">
            <h2>Panel Administrativo - CRUD de Productos</h2>
            {!esAdmin && (
                <p className="admin-subtitulo">
                    Estás viendo únicamente los productos que vos cargaste.
                </p>
            )}

            {/* Formulario para agregar / editar producto */}
            <div className="admin-form-card">
                <h3>{editandoId ? 'Editar Producto' : 'Agregar Nuevo Producto'}</h3>
                <form onSubmit={handleSubmit} noValidate className="admin-form-grid">
                    <div className="admin-campo">
                        <input 
                            type="text" name="nombre" placeholder="Nombre del producto" 
                            value={nuevoProducto.nombre} onChange={handleChange} onBlur={handleBlur}
                            className={erroresForm.nombre ? 'campo-error' : ''}
                        />
                        {erroresForm.nombre && <span className="admin-error-texto">{erroresForm.nombre}</span>}
                    </div>

                    <div className="admin-campo">
                        <input 
                            type="number" name="precio" placeholder="Precio del producto" min="0" step="0.01"
                            value={nuevoProducto.precio} onChange={handleChange} onBlur={handleBlur}
                            className={erroresForm.precio ? 'campo-error' : ''}
                        />
                        {erroresForm.precio && <span className="admin-error-texto">{erroresForm.precio}</span>}
                    </div>

                    <div className="admin-campo">
                        <input 
                            type="text" name="descripcion" placeholder="Describí brevemente el producto" 
                            value={nuevoProducto.descripcion} onChange={handleChange} onBlur={handleBlur}
                            className={erroresForm.descripcion ? 'campo-error' : ''}
                        />
                        {erroresForm.descripcion && <span className="admin-error-texto">{erroresForm.descripcion}</span>}
                    </div>

                    <div className="admin-campo">
                        <input 
                            type="number" name="stock" placeholder="Cantidad disponible" min="0" step="1"
                            value={nuevoProducto.stock} onChange={handleChange} onBlur={handleBlur}
                            className={erroresForm.stock ? 'campo-error' : ''}
                        />
                        {erroresForm.stock && <span className="admin-error-texto">{erroresForm.stock}</span>}
                    </div>

                    <div className="admin-campo">
                        <select
                            name="categoria"
                            value={nuevoProducto.categoria}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            className={erroresForm.categoria ? 'campo-error' : ''}
                        >
                            <option value="">Elegí una categoría...</option>
                            {CATEGORIAS.map((cat) => (
                                <option key={cat} value={cat}>{cat}</option>
                            ))}
                        </select>
                        {erroresForm.categoria && <span className="admin-error-texto">{erroresForm.categoria}</span>}
                    </div>

                    <div className="admin-campo admin-campo-imagen">
                        <label className="admin-label-imagen">Imagen del producto</label>
                        <input type="file" accept="image/*" onChange={handleImagenChange} />
                        {previewImagen && (
                            <img src={previewImagen} alt="Vista previa" className="admin-preview-imagen" />
                        )}
                    </div>

                    <div className="admin-form-botones">
                        <button
                            type="submit"
                            disabled={guardando}
                            className={editandoId ? 'admin-btn-guardar' : 'admin-btn-crear'}
                        >
                            {guardando ? 'Guardando...' : (editandoId ? 'Guardar Cambios' : 'Crear Producto')}
                        </button>
                        {editandoId && (
                            <button type="button" onClick={cancelarEdicion} className="admin-btn-cancelar">
                                Cancelar
                            </button>
                        )}
                    </div>
                </form>
            </div>

            {/* Listado de productos para administrar */}
            <h3>{esAdmin ? 'Productos Existentes en la Base de Datos' : 'Mis Productos'}</h3>
            <div className="admin-lista">
                {productosVisibles.length > 0 ? (
                    productosVisibles.map((prod) => (
                        <div key={prod._id} className="admin-item">
                            <div className="admin-item-info">
                                <img
                                    src={prod.imagen || '/cajas/placeholder.jpg'}
                                    alt={prod.nombre}
                                    onError={(e) => { e.target.onerror = null; e.target.src = '/cajas/placeholder.jpg'; }}
                                    className="admin-item-imagen"
                                />
                                <div>
                                    <strong>{prod.nombre}</strong> - ${prod.precio} (Stock: {prod.stock}) | <span className="admin-item-categoria">{prod.categoria}</span>
                                </div>
                            </div>
                            <div className="admin-item-acciones">
                                <button onClick={() => empezarEdicion(prod)} className="admin-btn-editar">
                                    Editar
                                </button>
                                <button onClick={() => eliminarProducto(prod._id)} className="admin-btn-eliminar">
                                    Eliminar
                                </button>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="admin-lista-vacia">
                        {esAdmin
                            ? 'Todavía no hay productos cargados en la plataforma.'
                            : 'Todavía no cargaste ningún producto. Usá el formulario de arriba para agregar el primero.'}
                    </p>
                )}
            </div>

            {/* Sección de usuarios: solo Administrador */}
            {esAdmin && (
                <div className="admin-usuarios-section">
                    <h2>Gestión de Usuarios</h2>
                    {cargandoUsuarios ? (
                        <Spinner texto="Cargando usuarios..." />
                    ) : (
                        <div className="admin-lista">
                            {usuarios.map((u) => (
                                <div key={u._id} className="admin-usuario-item">
                                    <div>
                                        <strong>{u.nombre}</strong> — {u.email}
                                        {u._id === user?.id && <span className="admin-usuario-vos"> (vos)</span>}
                                    </div>
                                    <div className="admin-usuario-acciones">
                                        <select
                                            value={u.rol}
                                            onChange={(e) => cambiarRol(u._id, e.target.value)}
                                        >
                                            <option value="user">Comprador</option>
                                            <option value="vendedor">Vendedor</option>
                                            <option value="admin">Administrador</option>
                                        </select>
                                        {u._id !== user?.id && (
                                            <button onClick={() => eliminarUsuario(u._id)} className="admin-btn-eliminar">
                                                Eliminar
                                            </button>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
