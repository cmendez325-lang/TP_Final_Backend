import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { eliminarDelCarrito, vaciarCarrito } from '../redux/slices/carritoSlice';
import './Carrito.css';

export default function Carrito() {
    const dispatch = useDispatch();
    const items = useSelector((state) => state.carrito?.items || []);

    // Calcular el total de la compra
    const total = items.reduce((acc, item) => acc + (item.precio * item.cantidad), 0);

    if (items.length === 0) {
        return (
            <div className="carrito-vacio">
                <h2>Tu carrito está vacío</h2>
                <p>Explora el catálogo para agregar productos.</p>
            </div>
        );
    }

    return (
        <div className="carrito-container">
            <h2>Carrito de Compras</h2>

            <div className="carrito-lista">
                {items.map((item) => (
                    <div key={item._id || item.id} className="carrito-item">
                        <div className="carrito-item-info">
                            <img
                                src={item.imagen || '/cajas/placeholder.jpg'}
                                alt={item.nombre}
                                className="carrito-item-imagen"
                                onError={(e) => { e.target.onerror = null; e.target.src = '/cajas/placeholder.jpg'; }}
                            />
                            <div>
                                <h4 className="carrito-item-nombre">{item.nombre}</h4>
                                <p className="carrito-item-cantidad">Cantidad: {item.cantidad}</p>
                            </div>
                        </div>

                        <div className="carrito-item-derecha">
                            <p className="carrito-item-precio">
                                ${(item.precio * item.cantidad).toLocaleString()}
                            </p>
                            <button
                                className="carrito-btn-eliminar"
                                onClick={() => dispatch(eliminarDelCarrito(item._id || item.id))}
                            >
                                Eliminar
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            {/* Total y Acciones */}
            <div className="carrito-resumen">
                <button className="carrito-btn-vaciar" onClick={() => dispatch(vaciarCarrito())}>
                    Vaciar Carrito
                </button>
                <div className="carrito-total-info">
                    <h3>Total: ${total.toLocaleString()}</h3>
                    <button className="carrito-btn-finalizar">
                        Finalizar Compra
                    </button>
                </div>
            </div>
        </div>
    );
}
